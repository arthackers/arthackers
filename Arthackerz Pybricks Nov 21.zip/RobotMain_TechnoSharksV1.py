""" System Files """
from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Icon, Color, Direction, Port, Side, Stop
from pybricks.robotics import GyroDriveBase
from pybricks.tools import wait, StopWatch

""" Our files """

""" Get all the functions from our Library
    Use any function in the library with MineStemLib.getHeading()
    """
from MineStemLib import resetHeading

from RobotHeart import RobotHeart
from DudeWhoWillRunMyAssignments import DudeWhoWillRunMyAssignments
from RobotAssignment import RobotAssignment
from RobotRun1 import RobotRun1

""" General notes on coding for FLL robots
    1. Stable straight speed: 200 with acceleration and deceleration of 100
        It will go at 200mm/s and will accelerate at 100 mm/s2
        and decelerate at 100 mm/s2
    2. Stable turn speed: 50 with 0 acceleration
    3. Fast return to home speed: 500 with accleration 100 
    """


myPrimeHub = PrimeHub()

left_wheel_motor = Motor(Port.A)
right_wheel_motor = Motor(Port.B, Direction.COUNTERCLOCKWISE)
left_attachment_motor = Motor(Port.C)
right_attachment_motor = Motor(Port.D)

""" LEFT ATTACHMENT
    1. Speed in degrees/s
    1. Angle of rotation in degrees. Positive angle means clockwise
"""
def leftAttachment(speed,angle):
    left_attachment_motor.run_angle(speed,angle,then=Stop.HOLD,wait=True)

def rightAttachment(speed,angle):
    right_attachment_motor.run_angle(speed,angle,then=Stop.HOLD,wait=True)

#Diameter of the wheels in mm
wheel_dia = 49.5
#The wheels axle track size. This is the distance in mm between the
#two points where both the wheels touch the ground
wheel_axle_dist = 120
drive_base = GyroDriveBase(left_wheel_motor, right_wheel_motor, wheel_diameter=wheel_dia, axle_track=wheel_axle_dist)
my_color_sensor = ColorSensor(Port.E)

""" Menu
"""
pressed = []
run_number = 1
myPrimeHub.display.char(str(run_number))
last_buttons = ()

def run1():
    """ Write Run 1 code here """
    resetHeading(myPrimeHub) #resets Yaw to 0

def run2():
    resetHeading(myPrimeHub) #resets Yaw to 0
    rightAttachment(200, 60)
    drive_base.settings(straight_speed=200,straight_acceleration=100,turn_rate=50)
    drive_base.straight(475)
    wait(100)
    drive_base.turn(-14)
    wait(100)
    rightAttachment(200, -60)
    wait(100)
    drive_base.turn(-44)
    wait(100)
    drive_base.straight(-70)
    wait(100)
    drive_base.turn(7)
    wait(100)
    rightAttachment(50,90)
    wait(100)
    drive_base.turn(-27)
    wait(100)
    drive_base.straight(160)
    wait(100)
    drive_base.turn(45)
    wait(100)
    drive_base.straight(150)
    wait(100)
    drive_base.turn(40)
    wait(100)
    drive_base.straight(130)
    wait(100)
    drive_base.turn(-10)

    drive_base.drive()
    while True:
        cur_reflection = my_color_sensor.reflection()
        if (cur_reflection < 20):
            print(cur_reflection)
            drive_base.stop
    """
    wait(100)
    drive_base.turn(-21)
    wait(100)
    drive_base.straight(160)
    wait(100)
    drive_base.turn(30)
    wait(100)
    drive_base.straight(30)
    wait(100)
    drive_base.turn(-70)
    wait(100)
    drive_base.turn(-50)
    wait(100)"""
    """ In front of the Tower
    drive_base.straight(100)
    wait(100)
    leftAttachment(400,200)
    wait(100)"""




def run3():
    resetHeading(myPrimeHub) #resets Yaw to 0
    drive_base.settings(straight_speed=200,straight_acceleration=100,turn_rate=50)
    
    #drive_base.turn(2);
    #wait(100)
    """drive_base.straight(370)
    wait(100)
    drive_base.straight(-250)
    wait(100)
    """

    drive_base.straight(65)
    wait(100)
    drive_base.turn(45)
    wait(100)
    drive_base.straight(400)
    wait(100)
    #drive_base.turn(5)
    #wait(100)
    #drive_base.straight(13)
    #wait(100)
    leftAttachment(250,-2040)
    wait(100)
    rightAttachment(50,-140)
    wait(100)
    drive_base.straight(-1000)
    wait(100)
    drive_base.stop()
    """
    drive_base.drive(700, 0)
    while True:
        cur_reflection = my_color_sensor.reflection()
        if cur_reflection < 15:
            print(cur_reflection)
            drive_base.stop()
    """
def run4():
    resetHeading(myPrimeHub) #resets Yaw to 0
    drive_base.straight(50)

def run5():
    resetHeading(myPrimeHub) #resets Yaw to 0
    drive_base.straight(50)


""" Permanent loop to process any button that is pressed """
while True:
    buttons = myPrimeHub.buttons.pressed()
    released_buttons = set(last_buttons) - set(buttons)

    """ Process the button that was pressed """
    if (Button.LEFT in released_buttons):
        run_number = run_number + 1
        if run_number > 5:
            run_number = 1
        myPrimeHub.display.char(str(run_number))
    
    if (Button.RIGHT in released_buttons):
        if run_number == 1:
                run1()
        elif run_number == 2:
                run2()
        elif run_number == 3:
                run3()
        elif run_number == 4:
                run4()
        elif run_number == 5:
                run5()
        
        

    last_buttons = buttons
