""" TABLE SPECIFIC PARAMETERS

"""
#In Evergreen - right most table = 12
#In Saratoga - at entrance left table = 15
max_black_color_reflection = 15

min_white_color_reflection = 60
PK_straight = 1
PK_turn = 1


""" System Files """
from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Icon, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

""" Our files """

""" Get all the functions from our Library
    """
from MineStemLib import resetHeading
from MineStemLib import myHeading

from RobotHeart import RobotHeart
from DudeWhoWillRunMyAssignments import DudeWhoWillRunMyAssignments
from RobotAssignment import RobotAssignment
from RobotRun1 import RobotRun1

""" General notes on coding for FLL robots
    1. Stable straight speed: 200 with acceleration and deceleration of 100
        It will go at 200mm/s and will accelerate at 100 mm/s2
        and decelerate at 100 mm/s2
    2. Stable turn speed: 50 with 0 acceleration
    3. Fast return to home speed: 500 with accleration 100 
    """


myPrimeHub = PrimeHub()
myRobotHeart = RobotHeart()
myDudeWhoWillRunMyAssignments = DudeWhoWillRunMyAssignments

left_wheel_motor = Motor(Port.A)
right_wheel_motor = Motor(Port.B, Direction.COUNTERCLOCKWISE)
left_attachment_motor = Motor(Port.C)
right_attachment_motor = Motor(Port.D)

""" LEFT ATTACHMENT
    1. Speed in degrees/s
    1. Angle of rotation in degrees. Positive angle means clockwise
"""
def leftAttachment(speed,angle):
    left_attachment_motor.run_angle(speed,angle,then=Stop.HOLD,wait=True)

def rightAttachment(speed,angle):
    right_attachment_motor.run_angle(speed,angle,then=Stop.HOLD,wait=True)

#Diameter of the wheels in mm
wheel_dia = 49.5
#The wheels axle track size. This is the distance in mm between the
#two points where both the wheels touch the ground
wheel_axle_dist = 120
drive_base = DriveBase(left_wheel_motor, right_wheel_motor, wheel_diameter=wheel_dia, axle_track=wheel_axle_dist)
drive_base.use_gyro(True)
left_color_sensor = ColorSensor(Port.E)
right_color_sensor = ColorSensor(Port.F)

""" Find Line
"""
def findBlackLine(color_sensor):
    drive_base.drive(100,0)
    reading_count = 1
    while True:
        cur_reflection = color_sensor.reflection()
        """
        reading_count = reading_count + 1
        print(reading_count)
        print(":")
        print(cur_reflection)
        print("\n")
        """
        if (cur_reflection < max_black_color_reflection):
            #print(cur_reflection)
            drive_base.stop()
            break
    wait(100)

""" Menu
"""
pressed = []
run_number = 1
myPrimeHub.display.char(str(run_number))
last_buttons = ()

def run4():
    drive_base.settings(straight_speed=300,straight_acceleration=200,turn_rate=30)
    resetHeading(myPrimeHub) #resets Yaw to 0
    #Pull in the attachments
    rightAttachment(50,5)
    leftAttachment(50,5)

    drive_base.turn(-65)
    wait(100)
    drive_base.straight(565)
    wait(100)
    drive_base.turn(51)
    wait(100)
    
    drive_base.straight(500)
    wait(100)

    drive_base.straight(-100)
    wait(100)

    drive_base.turn(20)
    wait(100)

    #Drop the Right Attachment for the Blue Flower
    rightAttachment(50, -120)
    wait(100)
    drive_base.settings(straight_speed=100,straight_acceleration=50,turn_rate=30)
    drive_base.straight(-120)
    wait(100)
    drive_base.turn(30)
    wait(100)
    drive_base.straight(70, then=Stop.COAST)
    wait(100)

    drive_base.settings(straight_speed=300,straight_acceleration=200,turn_rate=30)
    #raise right attachment we used for Blue Flower
    rightAttachment(50, 120)
    wait(100)
    
    #leftAttachment(50, -50)
    #wait(100)
   
    drive_base.turn(30)
    wait(100)

    drive_base.straight(700, then=Stop.COAST)
    wait(100)
    drive_base.stop()

def run1():
    """ Write Run 1 code here """
    resetHeading(myPrimeHub) #resets Yaw to 0
    drive_base.settings(straight_speed=500,straight_acceleration=200,turn_rate=30, turn_acceleration=30)
    drive_base.straight(90)
    wait(100)
    drive_base.turn(-12)
    wait(100)
    drive_base.straight(68)
    drive_base.settings(straight_speed=500,straight_acceleration=200,turn_rate=60, turn_acceleration=60)
    wait(100)
    drive_base.turn(23,then=Stop.COAST)
    wait(100)
    drive_base.settings(straight_speed=500,straight_acceleration=200,turn_rate=30, turn_acceleration=30)
    leftAttachment(300,-100)
    wait(100)
    drive_base.straight(-10)
    wait(100)
    leftAttachment(300,120)
    wait(100)
    leftAttachment(300,-160)
    wait(100)
    #Dragon misson complete
    drive_base.turn(87.5)
    wait(100)
    drive_base.straight(250)
    wait(100)
    drive_base.turn(-59)
    wait(100)
    drive_base.straight(245, then=Stop.COAST)
    wait(100)
    drive_base.turn(17)
    wait(100)
    drive_base.straight(-10)
    wait(100)
    drive_base.turn(40)
    wait(100)
    drive_base.turn(56)
    wait(100)
    drive_base.straight(-420)
    wait(100)
    drive_base.straight(200)
    wait(100)
    drive_base.turn(50)
    wait(100)
    drive_base.straight(500,then=Stop.COAST)
    drive_base.stop()

def run2():
    resetHeading(myPrimeHub) #resets Yaw to 0
    rightAttachment(200, 60)
    
    drive_base.settings(straight_speed=300,straight_acceleration=200,turn_rate=20)
    drive_base.straight(475)
    wait(100)
    drive_base.turn(-15,then=Stop.COAST)
    wait(100)
    rightAttachment(150, -40)
    wait(100)
    rightAttachment(150, -60)
    wait(100)
    drive_base.turn(-20, then=Stop.COAST)
    wait(100)
    drive_base.straight(-150)
    wait(100)
    drive_base.turn(-25)
    wait(100)
    drive_base.straight(70)
    wait(100)
    drive_base.turn(10)
    wait(100)
    rightAttachment(50,120)
    wait(100)
    #Boat mission done

    drive_base.turn(-30)
    wait(100)
    drive_base.straight(200)
    wait(100)
    drive_base.turn(64)
    wait(100)
    #Find Black line
    drive_base.drive(150,0)
    while True:
        cur_reflection = left_color_sensor.reflection()
        if (cur_reflection < 15):
            print(cur_reflection)
            drive_base.stop()
            break
    wait(100)
    drive_base.straight(65,then=Stop.COAST)
    wait(100)
    drive_base.stop()
    #Do Tower Mission
    leftAttachment(500,1300)
    wait(100)
    """
    drive_base.straight(-70)
    wait(100)
    drive_base.turn(44)
    wait(100)
    drive_base.settings(straight_speed=200,straight_acceleration=100,turn_rate=20)
    drive_base.straight(50)
    wait(100)
    drive_base.turn(-30)
    drive_base.settings(straight_speed=500,straight_acceleration=100,turn_rate=20)
    drive_base.straight(1100)
    wait(100)
    drive_base.stop()
    """
def run2LastGood():
    resetHeading(myPrimeHub) #resets Yaw to 0
    rightAttachment(200, 60)
    
    drive_base.settings(straight_speed=300,straight_acceleration=200,turn_rate=20)
    drive_base.straight(475)
    wait(100)
    drive_base.turn(-15)
    wait(100)
    rightAttachment(150, -40)
    wait(100)
    rightAttachment(150, -60)
    wait(100)
    drive_base.turn(-20)
    wait(100)
    drive_base.straight(-150)
    wait(100)
    drive_base.turn(-25)
    wait(100)
    drive_base.straight(70)
    wait(100)
    drive_base.turn(10)
    wait(100)
    rightAttachment(50,120)
    wait(100)
    #Boat mission done

    drive_base.turn(-30)
    wait(100)
    drive_base.straight(200)
    wait(100)
    drive_base.turn(58)
    wait(100)
    #Find Black line
    drive_base.drive(150,0)
    while True:
        cur_reflection = left_color_sensor.reflection()
        if (cur_reflection < 15):
            print(cur_reflection)
            drive_base.stop()
            break
    wait(100)
 
    drive_base.settings(straight_speed=50,turn_rate=20)
    drive_base.straight(60)
    wait(100)
    drive_base.stop()
    wait(100)
    drive_base.straight(-35)
    wait(100)
    drive_base.stop()
    #Turn Right and be exactly same heading as when we started
    #Correct the heading to be exactly 0
    curHeading = myHeading(myPrimeHub)
    drive_base.turn(-curHeading)
    wait(100)
    drive_base.turn(9)
    drive_base.stop()
    drive_base.straight(35)
    wait(100)
    drive_base.stop()
    #Do Tower Mission
    leftAttachment(500,1400)
    wait(100)
    drive_base.straight(-70)
    wait(100)
    drive_base.turn(44)
    wait(100)
    drive_base.settings(straight_speed=200,straight_acceleration=100,turn_rate=20)
    drive_base.straight(69)
    wait(100)
    drive_base.turn(-41)
    drive_base.settings(straight_speed=500,straight_acceleration=100,turn_rate=20)
    drive_base.straight(1100)
    wait(100)
    drive_base.stop()

def run2Old():
    resetHeading(myPrimeHub) #resets Yaw to 0

    rightAttachment(200, 60)
    drive_base.settings(straight_speed=150,straight_acceleration=100,turn_rate=20)
    drive_base.straight(475)
    wait(100)
    drive_base.turn(-15)
    wait(100)
    rightAttachment(200, -40)
    wait(200)
    rightAttachment(200, -60)
    wait(200)
    
    drive_base.turn(-46)
    wait(100)
    drive_base.straight(-70)
    wait(100)
    drive_base.turn(10)
    wait(100)
    rightAttachment(150,120)
    wait(100)
    #Boat mission done

    drive_base.turn(-40)
    wait(100)
    drive_base.straight(230)
    wait(100)
    drive_base.turn(69)
    wait(100)

    #Find Black line
    drive_base.drive(100,0)
    while True:
        cur_reflection = left_color_sensor.reflection()
        if (cur_reflection < 15):
            print(cur_reflection)
            drive_base.stop()
            break
    wait(100)
    drive_base.settings(straight_speed=50,turn_rate=20)
    drive_base.straight(60)
    wait(100)
    drive_base.stop()
    wait(100)
    drive_base.straight(-30)
    wait(100)
    drive_base.stop()
    #Turn Right and be exactly same heading as when we started
    #Correct the heading to be exactly 0
    curHeading = myHeading(myPrimeHub)
    drive_base.turn(-curHeading)
    wait(100)
    drive_base.stop()
    drive_base.straight(30)
    wait(100)
    drive_base.stop()
    #Do Tower Mission
    leftAttachment(500,1400)
    wait(100)
    drive_base.straight(-70)
    wait(100)
    drive_base.turn(50)
    wait(100)
    drive_base.settings(straight_speed=200,straight_acceleration=100,turn_rate=20)
    drive_base.straight(100)
    wait(100)
    drive_base.turn(-31)
    drive_base.settings(straight_speed=500,straight_acceleration=100,turn_rate=20)
    drive_base.straight(1100)
    wait(100)
    drive_base.stop()

def run3():
    drive_base.settings(straight_speed=300,straight_acceleration=200,turn_rate=20)
    resetHeading(myPrimeHub) #resets Yaw to 0
    #Lock in the right attachment
    rightAttachment(100,5)
    wait(100)
    drive_base.turn(3)
    wait(500)
    drive_base.straight(350,then=Stop.COAST)
    wait(100)
    drive_base.straight(-200)
    wait(100)
    drive_base.turn(35)
    wait(100)
    drive_base.straight(170)
    wait(100)
    leftAttachment(800,-1500)
    wait(100)
    drive_base.turn(-3)
    wait(100)
    drive_base.straight(225,then=Stop.COAST)
    drive_base.stop()
    wait(400)
    drive_base.straight(-20)
    wait(200)
    drive_base.straight(60)
    leftAttachment(800, -2200)
    wait(100)
    rightAttachment(150,-120)
    wait(100)
    drive_base.straight(-60, then=Stop.COAST)
    wait(100)
    rightAttachment(150,120)
    wait(100)
    drive_base.straight(-150, then=Stop.COAST)
    wait(100)
    drive_base.turn(-30)
    drive_base.straight(-450, then=Stop.COAST)
    wait(100)
    drive_base.stop()


 
def run3BeforeIntegratingCamera():
    drive_base.settings(straight_speed=300,straight_acceleration=100,turn_rate=20)
    resetHeading(myPrimeHub) #resets Yaw to 0
    rightAttachment(150,5)
    wait(100)
    drive_base.straight(110)
    wait(100)
    drive_base.turn(-50)
    wait(100)
    drive_base.straight(135)
    wait(100)
    leftAttachment(800,-1500)
    wait(100)
    drive_base.turn(-3)
    wait(100)
    drive_base.straight(225)
    wait(100)
    leftAttachment(800, -2200)
    wait(100)
    rightAttachment(150,-120)
    wait(100)
    drive_base.straight(-30)
    wait(100)
    rightAttachment(150,20)
    wait(100)
    drive_base.straight(-30)
    wait(100)
    rightAttachment(150,120)
    wait(100)
    drive_base.straight(-500)
    wait(100)
    drive_base.stop()

def run3BeforeLeftTurnOnSomeTablesIssue():
    drive_base.settings(straight_speed=300,straight_acceleration=100,turn_rate=20)
    resetHeading(myPrimeHub) #resets Yaw to 0
    rightAttachment(150,5)
    wait(100)
    drive_base.straight(110)
    wait(100)
    drive_base.turn(-50)
    wait(100)
    drive_base.straight(135)
    wait(100)
    leftAttachment(800,-1500)
    wait(100)
    drive_base.straight(225)
    wait(100)
    leftAttachment(800, -2200)
    wait(100)
    rightAttachment(150,-120)
    wait(100)
    drive_base.straight(-30)
    wait(100)
    rightAttachment(150,20)
    wait(100)
    drive_base.straight(-30)
    wait(100)
    rightAttachment(150,120)
    wait(100)
    drive_base.straight(-500)
    wait(100)
    drive_base.stop()

def run4_OLDRUN4_forStage():
    drive_base.settings(straight_speed=150,straight_acceleration=100,turn_rate=20)
    resetHeading(myPrimeHub) #resets Yaw to 0
    rightAttachment(100,130)
    wait(100)
    drive_base.straight(-230)
    wait(100)
    drive_base.stop()
    drive_base.straight(350)
    wait(100)
    drive_base.stop()
    rightAttachment(100,-120)
    wait(100)
    drive_base.turn(-90)
    wait(100)
    #print(myHeading(myPrimeHub))

    #fix it so it is heading at 90 degrees from starting position
    my_cur_heading = myHeading(myPrimeHub)
    off_heading = 90 + my_cur_heading
    drive_base.turn(-off_heading)
    #print(myHeading(myPrimeHub))
    wait(100)
    drive_base.straight(500)
    wait(100)
    drive_base.turn(-45)
    wait(100)
    
    #find the black line with left sensor
    #print("Looking for Black\n")
    findBlackLine(right_color_sensor)
    #print(myHeading(myPrimeHub))
    
    drive_base.straight(125)
    wait(100)
    drive_base.turn(80)
    wait(100)

    drive_base.settings(straight_speed=800,straight_acceleration=400,turn_rate=20)
    drive_base.straight(-250,Stop.BRAKE)
    drive_base.stop()
    #print("A")
    #print(myHeading(myPrimeHub))
    wait(100)

    drive_base.straight(30)
    wait(100)
    drive_base.turn(3)
    wait(100)
    #print(myHeading(myPrimeHub))
    drive_base.straight(250)
    wait(100)

    leftAttachment(100,-180)
    wait(100)
    drive_base.straight(-150)
    wait(100)
    drive_base.turn(-65)
    wait(100)
    drive_base.settings(straight_speed=800,straight_acceleration=400,turn_rate=20)
    wait(100)
    drive_base.straight(-800)
    drive_base.stop()

def run5old():
    drive_base.settings(straight_speed=150,straight_acceleration=100,turn_rate=20)
    resetHeading(myPrimeHub) #resets Yaw to 0
    drive_base.straight(530)
    wait(100)
    drive_base.turn(-45)
    wait(100)
    #find the black line with left sensor
    #print("Looking for Black\n")
    findBlackLine(right_color_sensor)
    #print(myHeading(myPrimeHub))
    wait
    drive_base.straight(150)
    wait(100)
    drive_base.turn(-45)
    wait(100)
    drive_base.straight(250)
    wait(100)
    drive_base.turn(30)
    wait(100)
    drive_base.straight(300)
    wait(100)

    drive_base.turn(-22)
    wait(100)
    drive_base.straight(-135)
    wait(100)
    drive_base.turn(28)
    wait(100)
    drive_base.straight(-85)
    wait(100)
    drive_base.straight(-55)
    wait(100)
    drive_base.turn(-45)
    wait(100)
    drive_base.straight(-40)
    wait(100)
    drive_base.turn(20)
    drive_base.straight(250)
    wait(100)
    drive_base.turn(30)
    drive_base.straight(80)
    leftAttachment(100, 150)
    leftAttachment(90, 0)

    drive_base.stop()
   
    

""" Permanent loop to process any button that is pressed """
while True:
    buttons = myPrimeHub.buttons.pressed()
    released_buttons = set(last_buttons) - set(buttons)

    """ Process the button that was pressed """
    if (Button.LEFT in released_buttons):
        run_number = run_number + 1
        if run_number > 5:
            run_number = 1
        myPrimeHub.display.char(str(run_number))
    
    if (Button.RIGHT in released_buttons):
        if run_number == 1:
                run1()
                run_number = run_number + 1
                myPrimeHub.display.char(str(run_number))
        elif run_number == 2:
                run2()
                run_number = run_number + 1
                myPrimeHub.display.char(str(run_number))
        elif run_number == 3:
                run3()
                run_number = run_number + 1
                myPrimeHub.display.char(str(run_number))
        elif run_number == 4:
                run4()
                run_number = run_number + 1
                myPrimeHub.display.char(str(run_number))
        elif run_number == 5:
                run5()
                run_number = 1
                myPrimeHub.display.char(str(run_number))
        
    last_buttons = buttons
