""" TABLE SPECIFIC PARAMETERS

"""
#In Evergreen - right most table = 12
#In Saratoga - at entrance left table = 15
max_black_color_reflection = 15

min_white_color_reflection = 60
PK_straight = 1
PK_turn = 1


""" System Files """
from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Icon, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

""" Our files """

""" Get all the functions from our Library
    """
from MineStemLib import resetHeading
from MineStemLib import myHeading

from RobotHeart import RobotHeart
from DudeWhoWillRunMyAssignments import DudeWhoWillRunMyAssignments
from RobotAssignment import RobotAssignment
from RobotRun1 import RobotRun1

""" General notes on coding for FLL robots
    1. Stable straight speed: 200 with acceleration and deceleration of 100
        It will go at 200mm/s and will accelerate at 100 mm/s2
        and decelerate at 100 mm/s2
    2. Stable turn speed: 50 with 0 acceleration
    3. Fast return to home speed: 500 with accleration 100 
    """


myPrimeHub = PrimeHub()
myRunTime = StopWatch()
myTotalTime = StopWatch()
myRobotHeart = RobotHeart()
doTulip = True
myDudeWhoWillRunMyAssignments = DudeWhoWillRunMyAssignments

left_wheel_motor = Motor(Port.A)
right_wheel_motor = Motor(Port.B, Direction.COUNTERCLOCKWISE)
left_attachment_motor = Motor(Port.C)
right_attachment_motor = Motor(Port.D)

""" LEFT ATTACHMENT
    1. Speed in degrees/s
    1. Angle of rotation in degrees. Positive angle means clockwise
"""
def leftAttachment(speed,angle):
    left_attachment_motor.run_angle(speed,angle,then=Stop.COAST,wait=True)

def rightAttachment(speed,angle):
    right_attachment_motor.run_angle(speed,angle,then=Stop.COAST,wait=True)

#Diameter of the wheels in mm
wheel_dia = 49.5
#The wheels axle track size. This is the distance in mm between the
#two points where both the wheels touch the ground
wheel_axle_dist = 120
drive_base = DriveBase(left_wheel_motor, right_wheel_motor, wheel_diameter=wheel_dia, axle_track=wheel_axle_dist)
drive_base.use_gyro(True)
left_color_sensor = ColorSensor(Port.F)
right_color_sensor = ColorSensor(Port.F)

#MENU
pressed = []
run_number = 1
myPrimeHub.display.char(str(run_number))
last_buttons = ()

myRunTime.reset()
myTotalTime.reset()

#SOUND MIXER + 1 x ROMEO AND JULIET
def run1():
    myRunTime.reset()
    myRunTime.resume()
    resetHeading(myPrimeHub) #resets Yaw to 0
    drive_base.settings(straight_speed=800,straight_acceleration=300,turn_rate=30, turn_acceleration=20)
    rightAttachment(200,5)
    drive_base.straight(375,then=Stop.COAST)
    drive_base.settings(straight_speed=200,straight_acceleration=200,turn_rate=30, turn_acceleration=20)
    drive_base.straight(155,then=Stop.COAST)
    drive_base.turn(28,then=Stop.COAST)
    drive_base.straight(-90,then=Stop.COAST)
    drive_base.settings(straight_speed=800,straight_acceleration=300,turn_rate=800, turn_acceleration=800)
    drive_base.straight(-50,then=Stop.COAST)
    drive_base.turn(-55,then=Stop.COAST)
    drive_base.straight(120, then=Stop.COAST)
    drive_base.turn(-50,then=Stop.COAST)
    rightAttachment(200,-90)
    drive_base.straight(120)
    drive_base.settings(straight_speed=800,straight_acceleration=300,turn_rate=800, turn_acceleration=800)
    drive_base.straight(-150,then=Stop.COAST)
    rightAttachment(500, 100)
    drive_base.curve(-300,-135,then=Stop.COAST)
    drive_base.straight(-150,then=Stop.COAST)
    drive_base.stop()
    print("Run1 RUN TIME: ")
    print(myRunTime.time())
    print("\n")
    myRunTime.reset()

#SOUND MIXER + 2 x ROMEO AND JULIET
def run2():
    myRunTime.reset()
    myRunTime.resume()
    resetHeading(myPrimeHub) #resets Yaw to 0
    drive_base.settings(straight_speed=800,straight_acceleration=None,turn_rate=30, turn_acceleration=20)
    rightAttachment(200,5)
    drive_base.straight(375,then=Stop.COAST)
    drive_base.settings(straight_speed=40,straight_acceleration=200,turn_rate=30, turn_acceleration=20)
    drive_base.straight(150,then=Stop.COAST)
    drive_base.turn(28,then=Stop.COAST)
    drive_base.straight(-90,then=Stop.COAST)
    drive_base.settings(straight_speed=800,straight_acceleration=300,turn_rate=800, turn_acceleration=800)
    drive_base.straight(-50,then=Stop.COAST)
    drive_base.turn(-55,then=Stop.COAST)
    drive_base.straight(120, then=Stop.COAST)
    drive_base.turn(-55,then=Stop.COAST)
    rightAttachment(200,-90)
    drive_base.straight(120,)
    drive_base.straight(-120,then=Stop.COAST)
    drive_base.straight(120)
    rightAttachment(500, 100)
    drive_base.settings(straight_speed=800,straight_acceleration=300,turn_rate=800, turn_acceleration=800)
    drive_base.straight(-150,then=Stop.COAST)
    drive_base.curve(-300,-135,then=Stop.COAST)
    drive_base.straight(-150,then=Stop.COAST)
    drive_base.stop()
    print("Run2 RUN TIME: ")
    print(myRunTime.time())
    print("\n")
    myRunTime.reset()

#DRAGONNNN
def run3():
    myRunTime.reset()
    myRunTime.resume()
    resetHeading(myPrimeHub) #resets Yaw to 0
    drive_base.settings(straight_speed=800, straight_acceleration=800, turn_rate=800, turn_acceleration=800)
    rightAttachment(200, 5)
    drive_base.straight(300)
    drive_base.straight(-300)
    drive_base.stop()
    print("Run3 RUN TIME: ")
    print(myRunTime.time())
    print("\n")
    myRunTime.reset()

#BOAT
def run4():
    myRunTime.reset()
    myRunTime.resume()
    resetHeading(myPrimeHub) #resets Yaw to 0
    drive_base.settings(straight_speed=800,straight_acceleration=300,turn_rate=800, turn_acceleration=800)
    drive_base.straight(480, then=Stop.COAST)
    rightAttachment(150, -40)
    rightAttachment(150, -60)
    drive_base.turn(-10,then=Stop.COAST)
    drive_base.straight(-275,then=Stop.COAST)
    drive_base.straight(135,then=Stop.COAST)
    drive_base.turn(-35,then=Stop.COAST)
    drive_base.straight(15,then=Stop.COAST)
    rightAttachment(150,110)
    wait(100)
    drive_base.straight(-400,then=Stop.COAST)
    drive_base.stop()
    print("Run 4 RUN TIME: ")
    print(myRunTime.time())
    print("\n")
    myRunTime.reset()

#TOWER + 2 AUDIENCE
def run5():
    myRunTime.reset()
    myRunTime.resume()
    resetHeading(myPrimeHub) #resets Yaw to 0
    drive_base.settings(straight_speed=600,straight_acceleration=300,turn_rate=800, turn_acceleration=800)
    drive_base.turn(-10,then=Stop.HOLD)
    drive_base.straight(860,then=Stop.COAST)
    leftAttachment(500,1330)
    wait(100)
    drive_base.settings(straight_speed=800)
    drive_base.straight(-90, then=Stop.COAST)
    wait(100)
    drive_base.turn(64, then=Stop.COAST)
    drive_base.straight(180, then=Stop.COAST)
    wait(100)
    drive_base.straight(-50, then=Stop.COAST)
    drive_base.settings(turn_rate=400)
    drive_base.turn(-70, then=Stop.COAST)
    drive_base.stop()
    print("Run 5 RUN TIME: ")
    print(myRunTime.time())
    print("\n")
    myRunTime.reset()

#ROLLERCOASTER
def run6():
    myRunTime.reset()
    myRunTime.resume()
    resetHeading(myPrimeHub) #resets Yaw to 0
    drive_base.settings(straight_speed=800,straight_acceleration=300,turn_rate=30)
    resetHeading(myPrimeHub) #resets Yaw to 0
    rightAttachment(100,5) #lock in right attachment
    drive_base.straight(360,then=Stop.COAST)
    drive_base.straight(-440,then=Stop.COAST)
    drive_base.stop()
    print("Run5 RUN TIME: ")
    print(myRunTime.time())
    print("\n")
    myRunTime.reset()

#CHICKEN
def run7():
    myRunTime.reset()
    myRunTime.resume()
    resetHeading(myPrimeHub) #resets Yaw to 0
    drive_base.settings(straight_speed=800, turn_rate=100)
    drive_base.straight(290)
    drive_base.turn(15)
    leftAttachment(1000, -1400)
    drive_base.turn(-33,then=Stop.COAST)
    drive_base.straight(260,then=Stop.COAST)
    leftAttachment(1000,-2300)
    rightAttachment(150,-120)
    drive_base.straight(-60, then=Stop.COAST)
    rightAttachment(150, 120)
    drive_base.straight(-425)
    drive_base.stop()
    print("Run5 RUN TIME: ")
    print(myRunTime.time())
    print("\n")
    myRunTime.reset()

#STAGE + TULIP
def run8():
    myRunTime.reset()
    myRunTime.resume()
    drive_base.settings(straight_speed=800,straight_acceleration=800,turn_rate=45)
    resetHeading(myPrimeHub) #resets Yaw to 0
    drive_base.straight(375)
    drive_base.turn(-25)
    drive_base.straight(250)
    drive_base.turn(28, then=Stop.COAST)
    drive_base.straight(220,then=Stop.COAST)
    drive_base.straight(-240,then=Stop.COAST)
    drive_base.turn(27, then=Stop.COAST)
    drive_base.straight(220,then=Stop.COAST)
    leftAttachment(800, -185)
    leftAttachment(800, 185)
    drive_base.settings(straight_speed=800,straight_acceleration=800,turn_rate=80)
    drive_base.straight(-120,then=Stop.COAST)
    drive_base.stop()

    if doTulip == True:
        drive_base.turn(-115)
        drive_base.straight(300,then=Stop.COAST)
        drive_base.curve(50, 60, then=Stop.COAST)
        drive_base.straight(-200,then=Stop.COAST)
        drive_base.turn(20)
        drive_base.straight(100)
        drive_base.straight(-90) 
        drive_base.curve(30, 40)
        drive_base.curve(200, 135)
        drive_base.straight(450)
        drive_base.stop()
    else:
        drive_base.turn(100)
    print("Run6 RUN TIME: ")
    print(myRunTime.time())
    print("\n")
    myRunTime.reset()

#MUSEUM + PURPLE + EXPERT - SLOW
def run9():
    myRunTime.reset()
    myRunTime.resume()
    drive_base.settings(straight_speed=300,straight_acceleration=300, turn_rate=40)
    resetHeading(myPrimeHub) #resets Yaw to 0
    rightAttachment(100, 10)
    drive_base.straight(410)
    drive_base.curve(260, -88)
    drive_base.straight(300)
    drive_base.turn(40)
    drive_base.straight(250)
    drive_base.straight(-155)
    drive_base.turn(-51)
    drive_base.straight(360)
    drive_base.turn(15)
    drive_base.straight(150)
    drive_base.turn(34)
    drive_base.straight(-170,then=Stop.COAST)
    drive_base.turn(40)
    drive_base.straight(100)
    leftAttachment(300, 155)
    rightAttachment(500, -83)
    rightAttachment(300, 100)
    drive_base.straight(-10)
    print("Run9 RUN TIME: ")
    print(myRunTime.time())
    print("\n")
    #print("TOTAL TIME: ")
    #print(myTotalTime.time())
    #print("\n")
    myRunTime.reset()
    myTotalTime.reset()

""" Permanent loop to process any button that is pressed """
while True:
    buttons = myPrimeHub.buttons.pressed()
    released_buttons = set(last_buttons) - set(buttons)

    """ Process the button that was pressed """
    if (Button.LEFT in released_buttons):
        run_number = run_number + 1
        if run_number > 9:
            run_number = 1
        myPrimeHub.display.char(str(run_number))
    
    if (Button.RIGHT in released_buttons):
        if run_number == 1:
                run1()
                myTotalTime.resume()
                print (myTotalTime.time())
                run_number = 3
                myPrimeHub.display.char(str(run_number))
        elif run_number == 2:
                run2()
                run_number += 1
                myPrimeHub.display.char(str(run_number))
        elif run_number == 3:
                run3()
                run_number += 1
                myPrimeHub.display.char(str(run_number))
        elif run_number == 4:
                run4()
                run_number += 1
                myPrimeHub.display.char(str(run_number))
        elif run_number == 5:
                run5()
                run_number += 1
                myPrimeHub.display.char(str(run_number))
        elif run_number == 6:
                run6()
                run_number += 1
                myPrimeHub.display.char(str(run_number))
        elif run_number == 7:
                run7()
                run_number += 1
                myPrimeHub.display.char(str(run_number))
        elif run_number == 8:
            run8()
            if myTotalTime.time() >= 110000:
                doTulip = False
            else:
                doTulip = True
            run_number += 1
            myPrimeHub.display.char(str(run_number))
        elif run_number == 9:
                run9()
                run_number += 1
    last_buttons = buttons